using PalindromeCore;
using PalindromeCore.Repositories;
using PalindromeData.Models;
using PalindromeData.Repositories;
using System.Threading.Tasks;

namespace PalindromeData.Data
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly PalindromeDBContext _context;
        private Repositories.PalindromeRepository _palindromeRepository;
     

        public UnitOfWork(PalindromeDBContext context)
        {
            this._context = context;
        }

       
        public IPalindromeRepository palindromeRepository => _palindromeRepository = _palindromeRepository ?? new PalindromeRepository(_context);

        public async Task<int> CommitAsync()
        {
            return await _context.SaveChangesAsync();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}