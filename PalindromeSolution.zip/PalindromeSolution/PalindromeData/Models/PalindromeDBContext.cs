﻿using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Configuration;
using PalindromeData.Helper;

namespace PalindromeData.Models
{
    public partial class PalindromeDBContext : DbContext
    {
        private readonly IConfiguration configuration;  
        public PalindromeDBContext(IConfigManager configManager)
        {
            
        }

        public PalindromeDBContext(DbContextOptions<PalindromeDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<PalindromeCollection> PalindromeCollections { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
          
//            if (!optionsBuilder.IsConfigured)
//            {


            //#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
            //                optionsBuilder.UseSqlServer("Server=localhost;Database=PalindromeDB;Trusted_Connection=True;");
            //            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PalindromeCollection>(entity =>
            {
                entity.ToTable("PalindromeCollection");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.StringValue)
                    .IsRequired()
                    .HasMaxLength(350);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
