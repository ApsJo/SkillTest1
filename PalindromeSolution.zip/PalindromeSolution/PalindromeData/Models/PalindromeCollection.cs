﻿using System;
using System.Collections.Generic;

namespace PalindromeData.Models
{
    public partial class PalindromeCollection
    {
        public int Id { get; set; }
        public string StringValue { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
