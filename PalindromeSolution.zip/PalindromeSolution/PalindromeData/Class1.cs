﻿using System;

namespace PalindromeData
{
    public class Class1
    {
    }
}
