using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PalindromeCore.Models;
using PalindromeCore.Repositories;
using PalindromeData.Models;

namespace PalindromeData.Repositories
{
    public class PalindromeRepository : Repository<PalindromeEntity>, IPalindromeRepository
    {
        public PalindromeRepository(PalindromeDBContext context) 
            : base(context)
        { }

      
        private PalindromeDBContext PalindromeDBContext
        {
            get { return Context as PalindromeDBContext; }
        }

        public  void AddString(PalindromeEntity palindrome)
        {
            var newEntity = new PalindromeCollection() { StringValue = palindrome.StringValue, CreatedDate = DateTime.Now };
             PalindromeDBContext.AddAsync(newEntity);
            PalindromeDBContext.SaveChanges();
        }

        public async Task<IEnumerable<PalindromeEntity>> GetAllCollectionAsync()
        {
           var entities  = await PalindromeDBContext.PalindromeCollections.ToListAsync();
            var PalindromeList = new List<PalindromeEntity>();
            foreach (var x in entities)
            {
                var palm = new PalindromeEntity()
                {
                    Id = x.Id,
                    StringValue = x.StringValue,
                    CreatedDate = x.CreatedDate
                };
                PalindromeList.Add(palm);
            }

            return PalindromeList;
           
        }
    }
}