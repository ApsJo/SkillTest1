using System;
using System.Threading.Tasks;
using PalindromeCore.Repositories;

namespace PalindromeCore
{
    public interface IUnitOfWork : IDisposable
    {
        IPalindromeRepository palindromeRepository { get; }
     
        Task<int> CommitAsync();
    }
}