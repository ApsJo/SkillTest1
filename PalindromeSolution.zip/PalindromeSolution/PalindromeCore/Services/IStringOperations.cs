﻿using PalindromeCore.Models;


using System.Collections.Generic;
using System.Threading.Tasks;

namespace PalindromeCore.Services
{
    public interface IStringOperations
    {
        Task<IEnumerable<PalindromeEntity>> GetCollection();
        void AddString(PalindromeEntity palindromeEntity);
    }
}
