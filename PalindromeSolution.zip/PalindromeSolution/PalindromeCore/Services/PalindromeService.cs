﻿
using PalindromeCore.Models;

using PalindromeCore.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PalindromeCore.Services
{
    public class PalindromeService : IStringOperations
    {

        public IPalindromeRepository _iRepository { get; set; }
        public PalindromeService(IPalindromeRepository rep)

        {
            _iRepository = rep;

        }

        public void AddString(PalindromeEntity palindromeEntity)
        {
            // _iRepository.
            _iRepository.AddString(palindromeEntity);
        }



        Task<IEnumerable<PalindromeEntity>> IStringOperations.GetCollection()
        {
            return _iRepository.GetAllCollectionAsync();
        }
    }
}
