using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace PalindromeCore.Models
{
    public class PalindromeEntity
    {
        public PalindromeEntity()
        {

        }

        public int Id { get; set; }
        public string StringValue { get; set; }
        public DateTime CreatedDate { get; set; }

    }
}