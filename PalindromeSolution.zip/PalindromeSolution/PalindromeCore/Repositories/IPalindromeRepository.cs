using System.Collections.Generic;
using System.Threading.Tasks;
using PalindromeCore.Core.Repositories;
using PalindromeCore.Models;

namespace PalindromeCore.Repositories
{
    public interface IPalindromeRepository : IRepository<PalindromeEntity>
    {
        Task<IEnumerable<PalindromeEntity>> GetAllCollectionAsync();
        void AddString(PalindromeEntity palindromeentity);
    }
}