﻿using System;
using System.Linq;
using System.Text;

namespace PalindromeWeb.Extensions
{
	public static class StringExtension
    {
		public static string RemoveWhitespace(this string input)
		{
			return new string(input.ToCharArray()
				.Where(c => !Char.IsWhiteSpace(c))
				.ToArray());
		}
		public static string RemoveSpecialCharacters(this string str)
		{
			StringBuilder sb = new StringBuilder();
			foreach (char c in str)
			{
				if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') )
				{
					sb.Append(c);
				}
			}
			return sb.ToString();
		}
	}
}
