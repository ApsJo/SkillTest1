﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PalindromeCore.Models;
using PalindromeCore.Services;
using PalindromeData.Models;
using PalindromeWeb.Extensions;
using PalindromeWeb.Models;

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace PalindromeWeb.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

       
		
		private IStringOperations _iStringOperations;
		public HomeController(ILogger<HomeController> logger, IStringOperations iStringOperations)
		{
			_logger = logger;
			_iStringOperations = iStringOperations;
		}

		public IActionResult Index()
		{
			var palindromeCollectionList = GetStringList();
			
			var model = new IndexViewModel
			{
				PalindromeCollection = new PalindromeEntity
				{
					
					StringValue = "",
					CreatedDate= DateTime.Now
				},
				PalindromeCollectionList = palindromeCollectionList
			};
			return View(model);
		}
		[HttpPost]
		public bool InsertNewStringInMemory([FromBody] PalindromeEntity palindrome)
		{
			
			var newEntity = new PalindromeEntity() {  StringValue = palindrome.StringValue, CreatedDate = DateTime.Now };
			_iStringOperations.AddString(newEntity);
			return true;
		}
		
		[HttpPost]
	public int CheckPalindrome([FromBody] PalindromeCollection palindrome)
	{
			var list = _iStringOperations.GetCollection().Result.ToList();
			
			string  rev;
			var str  = palindrome.StringValue.RemoveWhitespace();
			str = str.RemoveSpecialCharacters();
			if (list.Any(l => l.StringValue == palindrome.StringValue))
			{
				Console.WriteLine(" " + palindrome.StringValue + " already exists in the system!");

				return 2033;
			}
			char[] ch = str.ToCharArray();
			Array.Reverse(ch);
			rev = new string(ch);
			bool b = str.Equals(rev, StringComparison.OrdinalIgnoreCase);
			if (b == true)
			{
				Console.WriteLine("" + str + " is a Palindrome!");
				return 1;
			}
			else
			{
				Console.WriteLine(" " + str + " is not a Palindrome!");
				return 2034;
				
				
			}
			
	}
	public List<PalindromeEntity> GetStringList()
		 {
			var xx = _iStringOperations.GetCollection().Result.OrderByDescending(s=>s.CreatedDate).ToList();
			var PalindromeList = new List<PalindromeEntity>();
			foreach (var x in xx)
			{
				var palm = new PalindromeEntity()
				{
					Id = x.Id,
					StringValue = x.StringValue,
					CreatedDate = x.CreatedDate
				};
				PalindromeList.Add(palm);
			}

			return PalindromeList;
		}

		public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
