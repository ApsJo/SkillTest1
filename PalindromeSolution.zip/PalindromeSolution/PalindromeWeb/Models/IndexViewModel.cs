using PalindromeCore.Models;
using PalindromeData.Models;
using System;

namespace PalindromeWeb.Models
{
    public class IndexViewModel
    {
        public PalindromeEntity PalindromeCollection { get; set; }

        public System.Collections.Generic.List<PalindromeEntity> PalindromeCollectionList { get; set; }
    }
}
