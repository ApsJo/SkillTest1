﻿using System;

namespace PalindromeServices
{
    public class Class1
    {
    }
}
