using PalindromeCore.Models;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace PalindromeServices
{
    public class PalindromeService : IStringOperations
    {
        private readonly IUnitOfWork _unitOfWork;
        public PalindromeService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<PalindromeEntity> CreatePalindrome(PalindromeEntity newPalindrome)
        {
            await _unitOfWork.Palindromes
                .AddAsync(newPalindrome);
            await _unitOfWork.CommitAsync();

            return newPalindrome;
        }

        public async Task<IEnumerable<PalindromeEntity>> GetAllPalindromes()
        {
            return await _unitOfWork.Palindromes.GetAllAsync();
        }

      
    }
}
